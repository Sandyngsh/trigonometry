import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { 
  Trophy, 
  ChevronRight, 
  RotateCcw, 
  HelpCircle, 
  Brain, 
  Compass, 
  AlertCircle,
  ThumbsUp,
  Star,
  Zap,
  ArrowRight
} from 'lucide-react';
import { GameState, Question } from './types';
import { generateQuestion, getWorkedSolution, formatValue } from './utils/mathUtils';
import TriangleSVG from './components/TriangleSVG';

const TOTAL_QUESTIONS = 15;

export default function App() {
  const [gameState, setGameState] = useState<GameState>(GameState.START);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  useEffect(() => {
    if (gameState === GameState.START) {
      const newQuestions = Array.from({ length: TOTAL_QUESTIONS }, (_, i) => generateQuestion(i + 1));
      setQuestions(newQuestions);
      setCurrentIndex(0);
      setScore(0);
    }
  }, [gameState]);

  const handleStart = () => {
    setGameState(GameState.PLAYING);
  };

  const currentQuestion = questions[currentIndex];
  
  const handleAnswerSelection = (choice: string) => {
    if (selectedAnswer !== null || !currentQuestion) return; // Prevent double clicks
    
    setSelectedAnswer(choice);
    const isAngle = currentQuestion.type === 'find_angle';
    const correct = choice === formatValue(currentQuestion.answer, isAngle);
    setIsCorrect(correct);
    if (correct) {
      setScore(s => s + 1);
      setTimeout(() => nextQuestion(), 1500);
    } else {
      setShowExplanation(true);
    }
  };

  const nextQuestion = () => {
    setSelectedAnswer(null);
    setIsCorrect(null);
    setShowExplanation(false);
    
    if (currentIndex < TOTAL_QUESTIONS - 1) {
      setCurrentIndex(c => c + 1);
    } else {
      setGameState(GameState.RESULTS);
      handleCelebrations(score + (isCorrect ? 1 : 0));
    }
  };

  const handleCelebrations = (finalScore: number) => {
    if (finalScore === 15) {
      // Fireworks logic
      const duration = 5 * 1000;
      const animationEnd = Date.now() + duration;
      const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

      const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

      const interval: any = setInterval(function() {
        const timeLeft = animationEnd - Date.now();

        if (timeLeft <= 0) {
          return clearInterval(interval);
        }

        const particleCount = 50 * (timeLeft / duration);
        confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
        confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
      }, 250);
    } else if (finalScore >= 12) {
      // Standard Confetti
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
  };

  return (
    <div className="min-h-screen blueprint-bg font-sans p-4 md:p-8 flex flex-col items-center justify-center">
      <AnimatePresence mode="wait">
        {gameState === GameState.START && (
          <motion.div
            key="start"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="max-w-2xl w-full bg-white rounded-3xl shadow-xl p-8 border border-slate-200 text-center"
          >
            <div className="w-20 h-20 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Compass className="w-10 h-10 text-blue-600" />
            </div>
            <h1 className="text-4xl font-display font-bold mb-4 tracking-tight">TrigQuest</h1>
            <p className="text-slate-600 text-lg mb-8">
              Master the SOH CAH TOA ratios in this 15-question challenge. 
              Find missing lengths and angles using sine, cosine, and tangent.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 text-left">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                <Brain className="w-5 h-5 text-purple-500 mb-2" />
                <h3 className="font-semibold text-sm">Find Sides</h3>
                <p className="text-xs text-slate-500">Calculate lengths of hypotenuse, opposite, or adjacent.</p>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                <Compass className="w-5 h-5 text-blue-500 mb-2" />
                <h3 className="font-semibold text-sm">Composite</h3>
                <p className="text-xs text-slate-500">Multi-step problems involving two right triangles.</p>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                <HelpCircle className="w-5 h-5 text-orange-500 mb-2" />
                <h3 className="font-semibold text-sm">Solutions</h3>
                <p className="text-xs text-slate-500">Explanations rounded to standard sig figs.</p>
              </div>
            </div>
            <button
              onClick={handleStart}
              className="group relative w-full py-4 bg-blue-600 text-white rounded-2xl font-bold text-lg shadow-lg shadow-blue-200 hover:bg-blue-700 transition-all flex items-center justify-center gap-2 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
              Start Challenge
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </motion.div>
        )}

        {gameState === GameState.PLAYING && questions.length > 0 && currentQuestion && (
          <motion.div
            key="playing"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-4xl w-full space-y-6"
          >
            <div className="flex justify-between items-center bg-white px-6 py-4 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex items-center gap-3">
                <div className="bg-blue-50 text-blue-700 font-mono font-bold px-3 py-1 rounded-lg text-sm">
                  Q{currentIndex + 1} / {TOTAL_QUESTIONS}
                </div>
                <div className="h-2 w-32 bg-slate-100 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-blue-500" 
                    initial={{ width: 0 }}
                    animate={{ width: `${((currentIndex + 1) / TOTAL_QUESTIONS) * 100}%` }}
                  />
                </div>
              </div>
              <div className="flex items-center gap-2 text-slate-500 font-medium">
                <Star className="w-4 h-4 text-amber-400" />
                Score: <span className="text-slate-900 font-bold">{score}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col justify-center">
                <h2 className="text-2xl font-display font-semibold mb-2">
                  {currentQuestion.type === 'composite' 
                    ? "Find the length of the marked side (?) in the composite diagram."
                    : currentQuestion.type === 'find_side' 
                      ? `Find the length of the ${currentQuestion.target} side.` 
                      : `Find the size of the marked angle.`}
                </h2>
                <p className="text-slate-500 mb-6 font-mono text-sm">
                  {currentQuestion.type === 'find_angle' ? "Round to 1 decimal place." : "Round to 3 significant figures."}
                </p>
                <TriangleSVG question={currentQuestion} />
              </div>

              <div className="flex flex-col gap-4">
                <div className="grid grid-cols-2 gap-4 h-full">
                  {currentQuestion.choices.map((choice, i) => (
                    <motion.button
                      key={`${currentIndex}-${i}`}
                      whileHover={{ scale: selectedAnswer === null ? 1.02 : 1 }}
                      whileTap={{ scale: selectedAnswer === null ? 0.98 : 1 }}
                      onClick={() => handleAnswerSelection(choice)}
                      disabled={selectedAnswer !== null}
                      className={`
                        p-6 rounded-3xl border-2 text-xl font-bold transition-all flex flex-col items-center justify-center gap-2
                        ${selectedAnswer === null 
                          ? 'border-slate-100 bg-white hover:border-blue-500 hover:shadow-md' 
                          : choice === formatValue(currentQuestion.answer, currentQuestion.type === 'find_angle')
                            ? 'border-green-500 bg-green-50 text-green-700'
                            : selectedAnswer === choice
                              ? 'border-red-500 bg-red-50 text-red-700'
                              : 'border-slate-100 bg-white opacity-50'
                        }
                      `}
                    >
                      {choice} {currentQuestion.unit}
                      {selectedAnswer !== null && choice === formatValue(currentQuestion.answer, currentQuestion.type === 'find_angle') && (
                        <Zap className="w-5 h-5 text-green-500 animate-bounce" />
                      )}
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>

            <AnimatePresence>
              {showExplanation && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="bg-white rounded-3xl border border-slate-200 shadow-lg p-8 relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 p-4 opacity-10">
                    <Brain className="w-24 h-24 text-blue-600" />
                  </div>
                  <div className="flex gap-4 items-start mb-6">
                    <div className="bg-red-100 p-3 rounded-2xl">
                      <AlertCircle className="w-6 h-6 text-red-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">Step-by-Step Solution</h3>
                      <p className="text-slate-500">Don't worry, here's how to solve it!</p>
                    </div>
                  </div>
                  <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 mb-6 font-mono whitespace-pre-line text-lg leading-relaxed">
                    {getWorkedSolution(currentQuestion)}
                  </div>
                  <button
                    onClick={nextQuestion}
                    className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition-colors"
                  >
                    Continue to Next Question <ArrowRight className="w-5 h-5" />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {gameState === GameState.RESULTS && (
          <motion.div
            key="results"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-xl w-full text-center"
          >
            <div className="bg-white rounded-[40px] shadow-2xl p-10 border border-slate-200 relative">
              <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 bg-white rounded-full shadow-lg flex items-center justify-center border-8 border-[#F8FAFC]">
                {score === 15 ? (
                  <Zap className="w-10 h-10 text-amber-500 fill-amber-500" />
                ) : score >= 12 ? (
                  <Star className="w-10 h-10 text-blue-500 fill-blue-500" />
                ) : (
                  <ThumbsUp className="w-10 h-10 text-slate-400" />
                )}
              </div>
              
              <h2 className="text-3xl font-display font-bold mt-6 mb-2">
                {score === 15 ? "Trigonometry Master!" : score >= 12 ? "Excellent Work!" : "Great Effort!"}
              </h2>
              
              <div className="my-8">
                <span className="text-7xl font-display font-black text-blue-600">
                  {score}
                </span>
                <span className="text-3xl font-display font-bold text-slate-300">
                  / {TOTAL_QUESTIONS}
                </span>
              </div>

              <div className="mb-8">
                {score === 15 ? (
                  <p className="text-slate-600 text-lg">Perfect marks! You've completely mastered right-angled trigonometry.</p>
                ) : score >= 12 ? (
                  <p className="text-slate-600 text-lg">So close to perfection! You have a very strong understanding of the ratios.</p>
                ) : (
                  <div className="space-y-4">
                    <p className="text-slate-600 text-lg">You've started your journey into trigonometry. Keep practicing!</p>
                    <div className="flex flex-wrap justify-center gap-4">
                      {/* CSS Stickers Replacement */}
                      <div className="bg-blue-50 border-2 border-blue-200 p-4 rounded-2xl rotate-3 shadow-sm flex items-center gap-2">
                        <Star className="w-5 h-5 text-blue-500 fill-blue-500" />
                        <span className="font-bold text-blue-700">Keep It Up!</span>
                      </div>
                      <div className="bg-amber-50 border-2 border-amber-200 p-4 rounded-2xl -rotate-2 shadow-sm flex items-center gap-2">
                        <Brain className="w-5 h-5 text-amber-500" />
                        <span className="font-bold text-amber-700">Nice Progress!</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <button
                onClick={() => setGameState(GameState.START)}
                className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold text-lg shadow-lg shadow-blue-200 hover:bg-blue-700 transition-all flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-5 h-5" />
                Try Challenge Again
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
