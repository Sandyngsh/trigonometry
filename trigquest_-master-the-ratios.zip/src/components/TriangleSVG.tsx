import { motion } from 'motion/react';
import { TriangleData, Question } from '../types';
import { formatValue } from '../utils/mathUtils';

interface TriangleSVGProps {
  question: Question;
}

export default function TriangleSVG({ question }: TriangleSVGProps) {
  const { triangle: data, secondaryTriangle: data2, target, given, secondaryGiven, type } = question;
  
  const scale = 10;
  const padding = 50;

  if (type === 'composite' && data2) {
    // Composite: Two triangles sharing the 'opposite' side (vertical)
    // T1: (x-adj1, y) to (x, y) to (x, y-opp)
    // T2: (x+adj2, y) to (x, y) to (x, y-opp)
    
    const adj1 = data.adjacent * scale;
    const opp = data.opposite * scale;
    const adj2 = data2.adjacent * scale;
    
    const width = adj1 + adj2 + padding * 2;
    const height = opp + padding * 2;
    
    const CX = padding + adj1;
    const CY = padding + opp;
    
    const A = { x: padding, y: CY };
    const C = { x: CX, y: CY };
    const B = { x: CX, y: padding };
    const D = { x: padding + adj1 + adj2, y: CY };

    return (
      <div className="relative w-full aspect-video max-w-[400px] mx-auto bg-white/50 rounded-xl border border-slate-200 shadow-sm overflow-hidden flex items-center justify-center p-4">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full drop-shadow-md">
          {/* Shared Height */}
          <line x1={C.x} y1={C.y} x2={B.x} y2={B.y} stroke="#94a3b8" strokeWidth="2" strokeDasharray="4" />
          
          {/* Right Angle Markers */}
          <path d={`M ${C.x - 10} ${C.y} L ${C.x - 10} ${C.y - 10} L ${C.x} ${C.y - 10}`} fill="none" stroke="#94a3b8" strokeWidth="1" />
          <path d={`M ${C.x + 10} ${C.y} L ${C.x + 10} ${C.y - 10} L ${C.x} ${C.y - 10}`} fill="none" stroke="#94a3b8" strokeWidth="1" />

          {/* Triangle 1 */}
          <motion.path
            d={`M ${A.x} ${A.y} L ${C.x} ${C.y} L ${B.x} ${B.y} Z`}
            fill="rgba(59, 130, 246, 0.05)"
            stroke="#3b82f6"
            strokeWidth="3"
            strokeLinejoin="round"
            initial={{ pathLength: 0 }} animate={{ pathLength: 1 }}
          />

          {/* Triangle 2 */}
          <motion.path
            d={`M ${D.x} ${D.y} L ${C.x} ${C.y} L ${B.x} ${B.y} Z`}
            fill="rgba(139, 92, 246, 0.05)"
            stroke="#8b5cf6"
            strokeWidth="3"
            strokeLinejoin="round"
            initial={{ pathLength: 0 }} animate={{ pathLength: 1 }}
          />

          {/* Labels T1 */}
          <text x={A.x + 15} y={A.y - 5} className="text-[14px] font-bold fill-blue-600">{data.angleA}°</text>
          <text x={(A.x + C.x)/2} y={C.y + 20} textAnchor="middle" className="text-[12px] fill-slate-600 font-mono">
            {given.includes('adjacent') ? `${formatValue(data.adjacent, false)} cm` : ''}
          </text>

          {/* Labels T2 */}
          <text x={D.x - 45} y={D.y - 5} className="text-[14px] font-bold fill-purple-600">{data2.angleA}°</text>
          <text x={(D.x + C.x)/2} y={C.y + 20} textAnchor="middle" className="text-[14px] fill-red-500 font-bold font-mono">?</text>
        </svg>
      </div>
    );
  }

  // Single Triangle logic
  const adj = data.adjacent * scale;
  const opp = data.opposite * scale;
  
  const A = { x: padding, y: padding + opp };
  const C = { x: padding + adj, y: padding + opp };
  const B = { x: padding + adj, y: padding };

  const width = adj + padding * 2;
  const height = opp + padding * 2;

  const isTarget = (key: string) => target === key;
  const isGiven = (key: string) => given.includes(key as any);

  const getLabel = (key: 'opposite' | 'adjacent' | 'hypotenuse' | 'angle') => {
    if (isTarget(key)) return '?';
    if (!isGiven(key)) return '';
    if (key === 'angle') return `${data.angleA}°`;
    return `${formatValue(data[key], false)} cm`;
  };

  return (
    <div className="relative w-full aspect-square max-w-[300px] mx-auto bg-white/50 rounded-xl border border-slate-200 shadow-sm overflow-hidden flex items-center justify-center p-4">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-full drop-shadow-md"
        style={{ transform: `rotate(${data.rotation}deg)` }}
      >
        <path d={`M ${C.x - 15} ${C.y} L ${C.x - 15} ${C.y - 15} L ${C.x} ${C.y - 15}`} fill="none" stroke="#94a3b8" strokeWidth="2" />
        <motion.path
          d={`M ${A.x} ${A.y} L ${C.x} ${C.y} L ${B.x} ${B.y} Z`}
          fill="rgba(59, 130, 246, 0.1)" stroke="#3b82f6" strokeWidth="3" strokeLinejoin="round"
          initial={{ pathLength: 0 }} animate={{ pathLength: 1 }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
        />
        <text x={A.x + 10} y={A.y - 5} className="text-[14px] font-bold fill-blue-600">{getLabel('angle')}</text>
        <text x={(A.x + C.x) / 2} y={C.y + 20} textAnchor="middle" className={`text-[12px] font-mono ${isTarget('adjacent') ? 'fill-red-500 font-bold' : 'fill-slate-600'}`}>{getLabel('adjacent')}</text>
        <text x={C.x + 10} y={(C.y + B.y) / 2} className={`text-[12px] font-mono ${isTarget('opposite') ? 'fill-red-500 font-bold' : 'fill-slate-600'}`}>{getLabel('opposite')}</text>
        <text x={(A.x + B.x) / 2 - 20} y={(A.y + B.y) / 2 - 10} textAnchor="middle" className={`text-[12px] font-mono ${isTarget('hypotenuse') ? 'fill-red-500 font-bold' : 'fill-slate-600'}`}>{getLabel('hypotenuse')}</text>
      </svg>
    </div>
  );
}
