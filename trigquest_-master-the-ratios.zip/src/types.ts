/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type QuestionType = 'find_side' | 'find_angle' | 'composite';

export interface TriangleData {
  angleA: number; // in degrees
  opposite: number;
  adjacent: number;
  hypotenuse: number;
  rotation: number;
}

export interface Question {
  id: number;
  type: QuestionType;
  triangle: TriangleData;
  secondaryTriangle?: TriangleData; // For composite diagrams
  sharedSide?: 'opposite' | 'adjacent' | 'hypotenuse';
  target: 'opposite' | 'adjacent' | 'hypotenuse' | 'angle' | 'composite_target';
  given: ('opposite' | 'adjacent' | 'hypotenuse' | 'angle')[];
  secondaryGiven?: ('opposite' | 'adjacent' | 'hypotenuse' | 'angle')[];
  answer: number;
  choices: string[];
  unit: string;
}

export enum GameState {
  START,
  PLAYING,
  FEEDBACK,
  RESULTS
}
