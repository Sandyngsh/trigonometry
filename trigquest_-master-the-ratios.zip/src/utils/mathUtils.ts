import { Question, QuestionType, TriangleData } from '../types';

export const degToRad = (deg: number) => (deg * Math.PI) / 180;
export const radToDeg = (rad: number) => (rad * 180) / Math.PI;

export function toSigFigs(num: number, sigFigs: number): number {
  if (num === 0) return 0;
  const d = Math.ceil(Math.log10(num < 0 ? -num : num));
  const power = sigFigs - d;
  const magnitude = Math.pow(10, power);
  const shifted = Math.round(num * magnitude);
  return shifted / magnitude;
}

export function formatValue(num: number, isAngle: boolean): string {
  if (isAngle) {
    return num.toFixed(1);
  }
  
  if (num === 0) return "0.00";
  
  // Use a heuristic for 3 significant figures without scientific notation
  // Standard trig values in this app are roughly 1 to 100
  const absNum = Math.abs(num);
  if (absNum >= 100) {
    return Math.round(num).toString();
  } else if (absNum >= 10) {
    return num.toFixed(1);
  } else {
    return num.toFixed(2);
  }
}

export function generateQuestion(id: number): Question {
  const rand = Math.random();
  let type: QuestionType = rand < 0.35 ? 'find_side' : rand < 0.7 ? 'find_angle' : 'composite';

  if (type === 'composite') {
    return generateCompositeQuestion(id);
  }

  // Random angle between 20 and 70 degrees
  const angleA = Math.floor(Math.random() * 50) + 20;
  // Random base side length
  const sideAdjacent = Math.floor(Math.random() * 15) + 5;
  
  const angleARad = degToRad(angleA);
  const sideOpposite = sideAdjacent * Math.tan(angleARad);
  const sideHypotenuse = sideAdjacent / Math.cos(angleARad);
  
  const triangle: TriangleData = {
    angleA,
    opposite: sideOpposite,
    adjacent: sideAdjacent,
    hypotenuse: sideHypotenuse,
    rotation: Math.floor(Math.random() * 4) * 90
  };

  let target: 'opposite' | 'adjacent' | 'hypotenuse' | 'angle';
  let given: ('opposite' | 'adjacent' | 'hypotenuse' | 'angle')[] = [];
  let answer: number;
  let unit: string;

  if (type === 'find_side') {
    const targets: ('opposite' | 'adjacent' | 'hypotenuse')[] = ['opposite', 'adjacent', 'hypotenuse'];
    target = targets[Math.floor(Math.random() * 3)];
    given = ['angle'];
    
    const otherSides = targets.filter(s => s !== target);
    const sideToGive = otherSides[Math.floor(Math.random() * otherSides.length)];
    given.push(sideToGive);
    
    answer = triangle[target as keyof TriangleData] as number;
    unit = "cm";
  } else {
    target = 'angle';
    const sides: ('opposite' | 'adjacent' | 'hypotenuse')[] = ['opposite', 'adjacent', 'hypotenuse'];
    const shuffled = [...sides].sort(() => 0.5 - Math.random());
    given = [shuffled[0], shuffled[1]];
    
    answer = triangle.angleA;
    unit = "°";
  }

  const choices = generateChoices(answer, type === 'find_angle');

  return {
    id,
    type,
    triangle,
    target,
    given,
    answer,
    choices,
    unit
  };
}

function generateCompositeQuestion(id: number): Question {
  const a1 = Math.floor(Math.random() * 30) + 30;
  const adj1 = Math.floor(Math.random() * 10) + 5;
  const opp1 = adj1 * Math.tan(degToRad(a1));
  const hyp1 = adj1 / Math.cos(degToRad(a1));

  const t1: TriangleData = {
    angleA: a1,
    opposite: opp1,
    adjacent: adj1,
    hypotenuse: hyp1,
    rotation: 0
  };

  const a2 = Math.floor(Math.random() * 30) + 30;
  const opp2 = opp1;
  const adj2 = opp2 / Math.tan(degToRad(a2));
  const hyp2 = opp2 / Math.sin(degToRad(a2));

  const t2: TriangleData = {
    angleA: a2,
    opposite: opp2,
    adjacent: adj2,
    hypotenuse: hyp2,
    rotation: 0
  };

  return {
    id,
    type: 'composite',
    triangle: t1,
    secondaryTriangle: t2,
    sharedSide: 'opposite',
    target: 'composite_target',
    given: ['adjacent', 'angle'],
    secondaryGiven: ['angle'],
    answer: adj2,
    choices: generateChoices(adj2, false),
    unit: 'cm'
  };
}

function generateChoices(answer: number, isAngle: boolean): string[] {
  const choices = new Set<string>();
  const formattedAnswer = formatValue(answer, isAngle);
  choices.add(formattedAnswer);
  
  while (choices.size < 4) {
    const offset = (Math.random() - 0.5) * (isAngle ? 15 : (answer * 0.5));
    const choice = formatValue(Math.max(1, answer + offset), isAngle);
    if (choice !== formattedAnswer) {
      choices.add(choice);
    }
  }
  
  return Array.from(choices).sort((a, b) => parseFloat(a) - parseFloat(b));
}

export function getWorkedSolution(q: Question): string {
  if (q.type === 'composite') {
    const t1 = q.triangle;
    const t2 = q.secondaryTriangle!;
    const shared = q.sharedSide!;
    
    return `Step 1: In the first triangle, find the shared side (${shared}).
    Use tan(${t1.angleA}°) = Opp / Adj
    Opp = ${t1.adjacent.toFixed(2)} × tan(${t1.angleA}°) 
    Opp ≈ ${t1.opposite.toFixed(2)} cm (Shared Side)
    
    Step 2: In the second triangle, use the shared side to find the target.
    Use tan(${t2.angleA}°) = Opp / Adj
    Adj = ${t1.opposite.toFixed(2)} / tan(${t2.angleA}°)
    Adj ≈ ${t2.adjacent.toFixed(2)} cm
    
    Final Answer: ${formatValue(q.answer, false)} cm`;
  }

  const { triangle, target, given } = q;
  const isAngle = q.type === 'find_angle';
  
  if (q.type === 'find_side') {
    const sideGiven = given.find(g => g !== 'angle')!;
    const valGiven = triangle[sideGiven as keyof TriangleData];
    const angle = triangle.angleA;
    const ans = formatValue(q.answer, false);
    
    if (target === 'opposite' && sideGiven === 'adjacent') {
      return `Use tan(θ) = Opposite / Adjacent. \n tan(${angle}°) = x / ${valGiven} \n x = ${valGiven} × tan(${angle}°) \n x ≈ ${ans} cm`;
    }
    if (target === 'adjacent' && sideGiven === 'opposite') {
      return `Use tan(θ) = Opposite / Adjacent. \n tan(${angle}°) = ${valGiven} / x \n x = ${valGiven} / tan(${angle}°) \n x ≈ ${ans} cm`;
    }
    if (target === 'opposite' && sideGiven === 'hypotenuse') {
      return `Use sin(θ) = Opposite / Hypotenuse. \n sin(${angle}°) = x / ${valGiven} \n x = ${valGiven} × sin(${angle}°) \n x ≈ ${ans} cm`;
    }
    if (target === 'hypotenuse' && sideGiven === 'opposite') {
      return `Use sin(θ) = Opposite / Hypotenuse. \n sin(${angle}°) = ${valGiven} / x \n x = ${valGiven} / sin(${angle}°) \n x ≈ ${ans} cm`;
    }
    if (target === 'adjacent' && sideGiven === 'hypotenuse') {
      return `Use cos(θ) = Adjacent / Hypotenuse. \n cos(${angle}°) = x / ${valGiven} \n x = ${valGiven} × cos(${angle}°) \n x ≈ ${ans} cm`;
    }
    if (target === 'hypotenuse' && sideGiven === 'adjacent') {
      return `Use cos(θ) = Adjacent / Hypotenuse. \n cos(${angle}°) = ${valGiven} / x \n x = ${valGiven} / cos(${angle}°) \n x ≈ ${ans} cm`;
    }
  } else {
    // find angle
    const side1 = given[0];
    const side2 = given[1];
    const val1 = triangle[side1 as keyof TriangleData];
    const val2 = triangle[side2 as keyof TriangleData];
    const ans = formatValue(q.answer, true);
    
    const set = new Set(given);
    if (set.has('opposite') && set.has('adjacent')) {
      const opp = triangle.opposite;
      const adj = triangle.adjacent;
      return `Use tan(θ) = Opposite / Adjacent. \n tan(θ) = ${opp.toFixed(2)} / ${adj.toFixed(2)} \n θ = tan⁻¹(${ (opp/adj).toFixed(3) }) \n θ ≈ ${ans}°`;
    }
    if (set.has('opposite') && set.has('hypotenuse')) {
      const opp = triangle.opposite;
      const hyp = triangle.hypotenuse;
      return `Use sin(θ) = Opposite / Hypotenuse. \n sin(θ) = ${opp.toFixed(2)} / ${hyp.toFixed(2)} \n θ = sin⁻¹(${ (opp/hyp).toFixed(3) }) \n θ ≈ ${ans}°`;
    }
    if (set.has('adjacent') && set.has('hypotenuse')) {
      const adj = triangle.adjacent;
      const hyp = triangle.hypotenuse;
      return `Use cos(θ) = Adjacent / Hypotenuse. \n cos(θ) = ${adj.toFixed(2)} / ${hyp.toFixed(2)} \n θ = cos⁻¹(${ (adj/hyp).toFixed(3) }) \n θ ≈ ${ans}°`;
    }
  }
  return "Use SOH CAH TOA to find the relationship between the given values.";
}
